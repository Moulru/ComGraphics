
// 20141488_P3View.cpp : CMy20141488_P3View Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "20141488_P3.h"
#endif

#include "20141488_P3Doc.h"
#include "20141488_P3View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy20141488_P3View

IMPLEMENT_DYNCREATE(CMy20141488_P3View, CView)

BEGIN_MESSAGE_MAP(CMy20141488_P3View, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_COMMAND(ID_ORTHGONAL_PROJECTION, &CMy20141488_P3View::OnOrthgonalProjection)
	ON_COMMAND(ID_PERSPECTIVE_PROJECTION, &CMy20141488_P3View::OnPerspectiveProjection)
	ON_WM_TIMER()
	ON_COMMAND(ID_GEOMETRIC_TRANSFORMATION, &CMy20141488_P3View::OnGeometricTransformation)
END_MESSAGE_MAP()

// CMy20141488_P3View ����/�Ҹ�

CMy20141488_P3View::CMy20141488_P3View()
	: m_pDC(NULL)
	, m_nProjectionMode(0)
	, m_dAspectRatio(0)
	, m_nMenuSelection(0)
	, m_fRevolutionAngle(0)
	, m_fTranslateX(0)
	, m_fTranslateY(0)
	, m_fTranslateZ(0)
	, m_nRotateX(0)
	, m_nRotateY(0)
	, m_nRotateZ(0)
	, m_fScaleX(0)
	, m_fScaleY(0)
	, m_fScaleZ(0)
	, m_bDisplayGeoDlg(false)
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
	m_fRevolutionAngle = 0.0f;
	m_nProjectionMode = GL_PERSPECTIVE_MODEL;
	m_nRotateX = 0.0f;
	m_nRotateY = 0.0f;
	m_nRotateZ = 0.0f;
	m_fScaleX = 1.0f;
	m_fScaleY = 1.0f;
	m_fScaleZ = 1.0f;
	m_fTranslateX = 0.0f;
	m_fTranslateY = 0.0f;
	m_fTranslateZ = -10.0f;
	m_bDisplayGeoDlg = FALSE;

}

CMy20141488_P3View::~CMy20141488_P3View()
{
}

BOOL CMy20141488_P3View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.

	return CView::PreCreateWindow(cs);
}

// CMy20141488_P3View �׸���

void CMy20141488_P3View::OnDraw(CDC* pDC)
{
	CMy20141488_P3Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
	GLfloat fRange = 150.0f;

	::glMatrixMode(GL_PROJECTION);
	::glLoadIdentity();

	switch (m_nProjectionMode)
	{
	case GL_ORTHOGONAL_MODEL:
		if (m_dAspectRatio >= 1) {
			glOrtho(-fRange, fRange, fRange / m_dAspectRatio, -fRange / m_dAspectRatio, -fRange*4.0f, fRange*4.0f);
		}
		else {
			glOrtho(-fRange*m_dAspectRatio, fRange*m_dAspectRatio, fRange , -fRange , -fRange*4.0f, fRange*4.0f);
		}
		break;
	case GL_PERSPECTIVE_MODEL:
		::gluPerspective(45.0f, m_dAspectRatio, 1.0f, 500.0f);
		break;
	default:
		break;
	}
	::glMatrixMode(GL_MODELVIEW);
	::glLoadIdentity();

	::glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	RenderScene();
	::glFinish();

	::SwapBuffers(m_pDC->GetSafeHdc());
}


// CMy20141488_P3View ����

#ifdef _DEBUG
void CMy20141488_P3View::AssertValid() const
{
	CView::AssertValid();
}

void CMy20141488_P3View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy20141488_P3Doc* CMy20141488_P3View::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy20141488_P3Doc)));
	return (CMy20141488_P3Doc*)m_pDocument;
}
#endif //_DEBUG


// CMy20141488_P3View �޽��� ó����


int CMy20141488_P3View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
	InitializeOpenGL();
	SetTimer(0, 50, NULL);
	return 0;
}


bool CMy20141488_P3View::InitializeOpenGL()
{
	m_pDC = new CClientDC(this);
	// �Լ��� ù��°�� Ŭ���̾�Ʈ ������ ���� DC�� ��� NULL�� �ƴ��� Ȯ��
	if (m_pDC == NULL) {
		MessageBox(_T("Error Obtaining DC"));
		return false;
	}

	// �ȼ� ������ �����ϱ����� �Լ�ȣ�� �� ����Ȯ��
	if (!SetupPixelFormat()) {
		return FALSE;
	}

	m_hRC = ::wglCreateContext(m_pDC->GetSafeHdc());
	if (m_hRC == 0) {
		MessageBox(_T("Error Creating RC"));
		return false;
	}

	if (::wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC) == FALSE) {
		MessageBox(_T("Error making RC Current"));
		return false;
	}

	::glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	::glClearDepth(1.0f);

	::glEnable(GL_DEPTH_TEST);
	return TRUE;

}


bool CMy20141488_P3View::SetupPixelFormat()
{
	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW |
		PFD_SUPPORT_OPENGL |
		PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
		24,
		0,0,0,0,0,0,
		0,
		0,
		0,
		0,0,0,0,
		16,
		0,
		0,
		PFD_MAIN_PLANE,
		0,
		0,0,0
	};

	int m_nPixelFormat = ::ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd);
	if (m_nPixelFormat == 0) {
		return FALSE;
	}

	if (::SetPixelFormat(m_pDC->GetSafeHdc(), m_nPixelFormat, &pfd) == FALSE) {
		return FALSE;
	}

	return TRUE;
}


void CMy20141488_P3View::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	

	if (0 >= cx || 0 >= cy) {
		return;
	}

	::glViewport(0, 0, cx, cy);

	m_dAspectRatio = (GLdouble)cx / (GLdouble)cy;

}


void CMy20141488_P3View::RenderScene()
{
	if (m_nMenuSelection == PROJECTION_MODEL) {
		glTranslatef(0.0f, 0.0f, -200.0f);

		glColor3f(1.0f, 0.0f, 0.0f);
		glutSolidSphere(10.0f, 15, 15);

		glColor3f(1.0f, 1.0f, 0.0f);

		glPushMatrix();
		glRotatef(m_fRevolutionAngle, 0.0f, 1.0f, 0.0f);
		glTranslatef(90.0f, 0.0f, 0.0f);
		glutSolidSphere(6.0f,15,15);
		glPopMatrix();

		glPushMatrix();
		glRotatef(45.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(m_fRevolutionAngle, 0.0f, 1.0f, 0.0f);
		glTranslatef(-70.0f, 0.0f, 0.0f);
		glutSolidSphere(6.0f, 15, 15);
		glPopMatrix();

		glPushMatrix();
		glRotatef(360.0f-45.0f, 0.0f, 0.0f, 1.0f);
		glRotatef(m_fRevolutionAngle, 0.0f, 1.0f, 0.0f);
		glTranslatef(0.0f, 0.0f, 60.0f);
		glutSolidSphere(6.0f, 15, 15);
		glPopMatrix();
	}

	if (m_nMenuSelection == GEOMETRIC_TRANSFORM) {
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glLoadIdentity();
		glTranslatef(m_fTranslateX, m_fTranslateY, m_fTranslateZ);
		glRotatef(m_nRotateX, 1.0f, 0.0f, 0.0f);
		glRotatef(m_nRotateY, 0.0f, 1.0f, 0.0f);
		glRotatef(m_nRotateZ, 0.0f, 0.0f, 1.0f);
		glScalef(m_fScaleX, m_fScaleY, m_fScaleZ);
		glColor3f(1.0f, 1.0f, 1.0f);

		glBegin(GL_LINE_LOOP);
			glVertex3f(-1.0f, 1.0f, 1.0f);
			glVertex3f(1.0f, 1.0f, 1.0f);
			glVertex3f(1.0f, -1.0f, 1.0f);
			glVertex3f(-1.0f, -1.0f, 1.0f);
		glEnd();

		glBegin(GL_LINE_LOOP);
			glVertex3f(-1.0f, 1.0f, -1.0f);
			glVertex3f(1.0f, 1.0f, -1.0f);
			glVertex3f(1.0f, -1.0f, -1.0f);
			glVertex3f(-1.0f, -1.0f, -1.0f);
		glEnd();

		glBegin(GL_LINES);
			glVertex3f(-1.0f, 1.0f, 1.0f);
			glVertex3f(-1.0f, 1.0f, -1.0f);
			glVertex3f(1.0f, 1.0f, 1.0f);
			glVertex3f(1.0f, 1.0f, -1.0f);
			glVertex3f(1.0f, -1.0f, 1.0f);
			glVertex3f(1.0f, -1.0f, -1.0f);
			glVertex3f(-1.0f, -1.0f, 1.0f);
			glVertex3f(-1.0f, -1.0f, -1.0f);
		glEnd();

		glBegin(GL_LINES);
			glColor3f(1.0f, 0.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(3.0f, 0.0f, 0.0f);

			glColor3f(0.0f, 1.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(0.0f, 3.0f, 0.0f);

			glColor3f(0.0f, 0.0f, 1.0f);
			glVertex3f(0.0f, 0.0f, 0.0f);
			glVertex3f(0.0f, 0.0f, 3.0f);
		glEnd();

	}
}


BOOL CMy20141488_P3View::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	return TRUE;
}


void CMy20141488_P3View::OnDestroy()
{
	CView::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.

	if (::wglMakeCurrent(0, 0) == FALSE) {
		MessageBox(_T("Could not make RC non-current"));
	}

	if (::wglDeleteContext(m_hRC) == FALSE) {
		MessageBox(_T("Could not delete RC"));
	}

	if (m_pDC) {
		delete m_pDC;
	}
	m_pDC = NULL;

	KillTimer(0);
}


void CMy20141488_P3View::OnOrthgonalProjection()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_nMenuSelection = PROJECTION_MODEL;
	m_nProjectionMode = GL_ORTHOGONAL_MODEL;
	InvalidateRect(NULL, FALSE);
}


void CMy20141488_P3View::OnPerspectiveProjection()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_nMenuSelection = PROJECTION_MODEL;
	m_nProjectionMode = GL_PERSPECTIVE_MODEL;
	InvalidateRect(NULL, FALSE);
}


void CMy20141488_P3View::OnTimer(UINT_PTR nIDEvent)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_fRevolutionAngle += 10.0f;
	if (m_fRevolutionAngle > 360.0f) {
		m_fRevolutionAngle = 0.0f;
	}
	InvalidateRect(NULL, FALSE);

	CView::OnTimer(nIDEvent);
}


void CMy20141488_P3View::OnGeometricTransformation()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_nMenuSelection = GEOMETRIC_TRANSFORM;
	m_nProjectionMode = GL_PERSPECTIVE_MODEL;
	if (m_bDisplayGeoDlg == FALSE) {
		m_GeoDlg.Create(IDD_DIALOG_GEOMETRIC, this);
		m_bDisplayGeoDlg = TRUE;
	} 
	m_GeoDlg.MoveWindow(800, 460, 480, 400);
	m_GeoDlg.ShowWindow(SW_SHOW);
}
