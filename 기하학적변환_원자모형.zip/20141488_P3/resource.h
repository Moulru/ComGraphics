//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 20141488_P3.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My20141488_P3TYPE           130
#define IDD_DIALOG_GEOMETRIC            310
#define IDC_EDIT_TRANSLATE_X            1000
#define IDC_EDIT_TRANSLATE_Y            1001
#define IDC_EDIT_TRANSLATE_Z            1002
#define IDC_EDIT_ROTATE_X               1003
#define IDC_EDIT_ROTATE_Y               1004
#define IDC_EDIT_ROTATE_Z               1005
#define IDC_EDIT_SCALE_X                1006
#define IDC_EDIT_SCALE_Y                1007
#define IDC_EDIT_SCALE_Z                1008
#define IDC_BUTTON_TRANSLATE_RESET      1009
#define IDC_BUTTON_ROTATE_RESET         1010
#define IDC_BUTTON_SCALE_RESET          1011
#define IDC_SPIN_TRANSLATE_X            1012
#define IDC_SPIN_TRANSLATE_Y            1013
#define IDC_SPIN_TRANSLATE_Z            1014
#define IDC_SPIN_SCALE_X                1015
#define IDC_SPIN_SCALE_Y                1016
#define IDC_SPIN_SCALE_Z                1017
#define IDC_SLIDER_ROTATE_X             1018
#define IDC_SLIDER_ROTATE_Y             1019
#define IDC_SLIDER_ROTATE_Z             1020
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_ORTHGONAL_PROJECTION         32773
#define ID_PERSPECTIVE_PROJECTION       32774
#define ID_32775                        32775
#define ID_GEOMETRIC_TRANSFORMATION     32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        312
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
