// AtDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_P4.h"
#include "AtDlg.h"
#include "afxdialogex.h"

#include "MainFrm.h"
#include "20141488_P4Doc.h"
#include "20141488_P4View.h"


// CAtDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CAtDlg, CDialogEx)

CAtDlg::CAtDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_AT, pParent)
	, m_strAtX(_T(""))
	, m_strAtY(_T(""))
	, m_strAtZ(_T(""))
{

}

CAtDlg::~CAtDlg()
{
}

void CAtDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_AT_X, m_strAtX);
	DDX_Text(pDX, IDC_EDIT_AT_Y, m_strAtY);
	DDX_Text(pDX, IDC_EDIT_AT_Z, m_strAtZ);
}


BEGIN_MESSAGE_MAP(CAtDlg, CDialogEx)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_AT_X, &CAtDlg::OnDeltaposSpinAtX)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_AT_Y, &CAtDlg::OnDeltaposSpinAtY)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_AT_Z, &CAtDlg::OnDeltaposSpinAtZ)
	ON_BN_CLICKED(IDC_BUTTON_RESET_AT, &CAtDlg::OnClickedButtonResetAt)
END_MESSAGE_MAP()


// CAtDlg �޽��� ó�����Դϴ�.


BOOL CAtDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	m_strAtX.Format(_T("%.1f"), pView->m_At[0]);
	m_strAtY.Format(_T("%.1f"), pView->m_At[1]);
	m_strAtZ.Format(_T("%.1f"), pView->m_At[2]);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CAtDlg::OnDeltaposSpinAtX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_At[0]++;
	}
	else {
		pView->m_At[0]--;
	}

	m_strAtX.Format(_T("%.1f"), pView->m_At[0]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CAtDlg::OnDeltaposSpinAtY(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_At[1]++;
	}
	else {
		pView->m_At[1]--;
	}

	m_strAtY.Format(_T("%.1f"), pView->m_At[1]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CAtDlg::OnDeltaposSpinAtZ(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_At[2]++;
	}
	else {
		pView->m_At[2]--;
	}

	m_strAtZ.Format(_T("%.1f"), pView->m_At[2]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CAtDlg::OnClickedButtonResetAt()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	pView->m_At[0] = 0;
	pView->m_At[1] = 0;
	pView->m_At[2] = -100;

	m_strAtX = "0.0";
	m_strAtY = "0.0";
	m_strAtZ = "-100.0";

	UpdateData(FALSE);
	pView->RedrawWindow();

}
