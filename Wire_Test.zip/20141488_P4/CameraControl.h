#pragma once
#include "afxcmn.h"
#include "FromDlg.h"
#include "AtDlg.h"
#include "UpDlg.h"


// CCameraControl ��ȭ �����Դϴ�.

class CCameraControl : public CDialogEx
{
	DECLARE_DYNAMIC(CCameraControl)

public:
	CCameraControl(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CCameraControl();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_CAMERA };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CTabCtrl m_tabSelection;
	CString m_strAngle;
	CFromDlg m_dlgFrom;
	CAtDlg m_dlgAt;
	CUpDlg m_dlgUp;
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeTabSelection(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinAngle(NMHDR *pNMHDR, LRESULT *pResult);
};
