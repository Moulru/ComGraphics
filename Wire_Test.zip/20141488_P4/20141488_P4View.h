
// 20141488_P4View.h : CMy20141488_P4View Ŭ������ �������̽�
//

#pragma once
#include "atltypes.h"
#include "CameraControl.h"

struct Vertex {
	float x;
	float y;
	float z;
};

struct Index {
	int Count;
	int List[30];
	float Red;
	float Green;
	float Blue;
};
class CMy20141488_P4View : public CView
{
protected: // serialization������ ��������ϴ�.
	CMy20141488_P4View();
	DECLARE_DYNCREATE(CMy20141488_P4View)

// Ư���Դϴ�.
public:
	CMy20141488_P4Doc* GetDocument() const;

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual void OnDraw(CDC* pDC);  // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// �����Դϴ�.
public:
	virtual ~CMy20141488_P4View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	DECLARE_MESSAGE_MAP()
public:
	HGLRC m_hRC;
	CDC* m_pDC;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	bool InitializeOpenGL();
	bool SetupPixelFormat();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	void RenderScene();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	GLfloat m_fRotX;
	GLfloat m_fRotY;
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	CPoint m_ptMouseDown;
	bool m_bRotate;
	bool m_bZoom;
	GLfloat m_fTransZ;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	GLdouble m_dAspectRatio;
	GLfloat m_From[3];
	GLfloat m_Up[3];
	GLfloat m_Angle;
	GLfloat m_At[3];
	bool m_bFileOpen;
	CString m_strFileType;
	CString m_strFileWinding;
	int m_nCountVertex;
	int m_nCountFace;
	int m_nCountEdge;
	Vertex m_Vertex[6000];
	Index m_FaceIndex[5000];
	afx_msg void OnFileOpen();
	CCameraControl m_dlgCameraControl;
	afx_msg void OnCameraControl();
	bool m_bDisplayCameraControl;
};

#ifndef _DEBUG  // 20141488_P4View.cpp�� ����� ����
inline CMy20141488_P4Doc* CMy20141488_P4View::GetDocument() const
   { return reinterpret_cast<CMy20141488_P4Doc*>(m_pDocument); }
#endif

