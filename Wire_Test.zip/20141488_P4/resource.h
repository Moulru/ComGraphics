//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 20141488_P4.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My20141488_P4TYPE           130
#define IDC_CURSOR_ROTATE               310
#define IDC_CURSOR_ZOOM                 311
#define IDD_DIALOG_CAMERA               312
#define IDD_DIALOG_FROM                 314
#define IDD_DIALOG_AT                   316
#define IDD_DIALOG2                     318
#define IDD_DIALOG_UP                   318
#define IDC_TAB_SELECTION               1000
#define IDC_EDIT_ANGLE                  1001
#define IDC_SPIN_ANGLE                  1002
#define IDC_EDIT_FROM_X                 1003
#define IDC_SPIN_FROM_X                 1004
#define IDC_EDIT_FROM_Y                 1005
#define IDC_SPIN_FROM_Y                 1006
#define IDC_EDIT_FROM_Z                 1007
#define IDC_SPIN_FROM_Z                 1008
#define IDC_BUTTON_RESET_FROM           1009
#define IDC_EDIT_AT_X                   1010
#define IDC_EDIT_AT_Y                   1011
#define IDC_EDIT_AT_Z                   1012
#define IDC_SPIN_AT_X                   1013
#define IDC_SPIN_AT_Y                   1014
#define IDC_SPIN_AT_Z                   1015
#define IDC_BUTTON_RESET_AT             1016
#define IDC_EDIT_UP_X                   1017
#define IDC_EDIT_UP_Y                   1018
#define IDC_EDIT_UP_Z                   1019
#define IDC_SPIN_UP_X                   1020
#define IDC_SPIN_UP_Y                   1021
#define IDC_SPIN_UP_Z                   1022
#define IDC_BUTTON_RESET_UP             1023
#define ID_32771                        32771
#define ID_CAMERA_CONTROL               32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        320
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
