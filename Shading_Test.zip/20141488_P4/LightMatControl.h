#pragma once
#include "afxcmn.h"
#include "LightDlg.h"
#include "MateriaDlg.h"
//#include "20141488_P4Doc.h"
#include "MainFrm.h"
//#include "20141488_P4View.h"

// CLightMatControl ��ȭ �����Դϴ�.

class CLightMatControl : public CDialogEx
{
	DECLARE_DYNAMIC(CLightMatControl)

public:
	CLightMatControl(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CLightMatControl();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_LIGHT_MAT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CTabCtrl m_tabLightMat;
	CMaterialDlg m_dlgMat;
	CLightDlg m_dlgLight;
	virtual BOOL OnInitDialog();
	int m_nTabSelection;
	afx_msg void OnSelchangeTabLightMat(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnClickedButtonReset();
};
