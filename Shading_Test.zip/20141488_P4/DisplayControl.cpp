// DisplayControl.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_P4.h"
#include "DisplayControl.h"
#include "afxdialogex.h"

#include "MainFrm.h"
#include "20141488_P4Doc.h"
#include "20141488_P4View.h"

// CDisplayControl ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CDisplayControl, CDialogEx)

CDisplayControl::CDisplayControl(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_DISPLAY, pParent)
{

}

CDisplayControl::~CDisplayControl()
{
}

void CDisplayControl::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDisplayControl, CDialogEx)
	ON_COMMAND(IDC_RADIO_WIRE, &CDisplayControl::OnRadioWire)
	ON_COMMAND(IDC_RADIO_FLAT, &CDisplayControl::OnRadioFlat)
	ON_COMMAND(IDC_RADIO_SMOOTH, &CDisplayControl::OnRadioSmooth)
	ON_BN_CLICKED(IDC_BUTTON_RESET, &CDisplayControl::OnClickedButtonReset)
END_MESSAGE_MAP()


// CDisplayControl �޽��� ó�����Դϴ�.


BOOL CDisplayControl::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());
	CButton* m_Button;

	switch (pView->m_nDisplayMode) {
	case WIRE_FRAME:
		m_Button = (CButton*)GetDlgItem(IDC_RADIO_WIRE);
		m_Button->SetCheck(TRUE);
		break;
	case FLAT_SHADING:
		m_Button = (CButton*)GetDlgItem(IDC_RADIO_FLAT);
		m_Button->SetCheck(TRUE);
		break;
	case SMOOTH_SHADING:
		m_Button = (CButton*)GetDlgItem(IDC_RADIO_SMOOTH);
		m_Button->SetCheck(TRUE);
		break;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CDisplayControl::OnRadioWire()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	pView->m_nDisplayMode = WIRE_FRAME;
	pView->RedrawWindow();
}


void CDisplayControl::OnRadioFlat()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	pView->m_nDisplayMode = FLAT_SHADING;
	pView->RedrawWindow();
}


void CDisplayControl::OnRadioSmooth()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	pView->m_nDisplayMode = SMOOTH_SHADING;
	pView->RedrawWindow();
}


void CDisplayControl::OnClickedButtonReset()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.

	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	CButton* m_Button;
	m_Button = (CButton*)GetDlgItem(IDC_RADIO_WIRE);
	m_Button->SetCheck(TRUE);

	m_Button = (CButton*)GetDlgItem(IDC_RADIO_FLAT);
	m_Button->SetCheck(TRUE);

	m_Button = (CButton*)GetDlgItem(IDC_RADIO_SMOOTH);
	m_Button->SetCheck(TRUE);

	pView->m_nDisplayMode = WIRE_FRAME;
	pView->RedrawWindow();
}
