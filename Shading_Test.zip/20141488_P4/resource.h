//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// 20141488_P4.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_My20141488_P4TYPE           130
#define IDC_CURSOR_ROTATE               310
#define IDC_CURSOR_ZOOM                 311
#define IDD_DIALOG_CAMERA               312
#define IDD_DIALOG_FROM                 314
#define IDD_DIALOG_AT                   316
#define IDD_DIALOG_UP                   318
#define IDD_DIALOG_DISPLAY              320
#define IDD_DIALOG_LIGHT_MAT            322
#define IDD_DIALOG_MAT                  324
#define IDD_DIALOG_LIGHT                326
#define IDC_TAB_SELECTION               1000
#define IDC_EDIT_ANGLE                  1001
#define IDC_SPIN_ANGLE                  1002
#define IDC_EDIT_FROM_X                 1003
#define IDC_SPIN_FROM_X                 1004
#define IDC_EDIT_FROM_Y                 1005
#define IDC_SPIN_FROM_Y                 1006
#define IDC_EDIT_FROM_Z                 1007
#define IDC_SPIN_FROM_Z                 1008
#define IDC_BUTTON_RESET_FROM           1009
#define IDC_EDIT_AT_X                   1010
#define IDC_EDIT_AT_Y                   1011
#define IDC_EDIT_AT_Z                   1012
#define IDC_SPIN_AT_X                   1013
#define IDC_SPIN_AT_Y                   1014
#define IDC_SPIN_AT_Z                   1015
#define IDC_BUTTON_RESET_AT             1016
#define IDC_EDIT_UP_X                   1017
#define IDC_EDIT_UP_Y                   1018
#define IDC_EDIT_UP_Z                   1019
#define IDC_SPIN_UP_X                   1020
#define IDC_SPIN_UP_Y                   1021
#define IDC_SPIN_UP_Z                   1022
#define IDC_BUTTON_RESET_UP             1023
#define IDC_BUTTON_RESET                1024
#define IDC_RADIO_WIRE                  1025
#define IDC_RADIO_FLAT                  1026
#define IDC_TAB_LIGHT_MAT               1026
#define IDC_RADIO_SMOOTH                1027
#define IDC_SLIDER_DIFFUSE_R            1028
#define IDC_SLIDER_DIFFUSE_G            1029
#define IDC_SLIDER_SHINE                1030
#define IDC_SLIDER_DIFFUSE_B            1031
#define IDC_EDIT_DIFFUSE_R              1032
#define IDC_EDIT_DIFFUSE_G              1033
#define IDC_EDIT_POSITION_X             1033
#define IDC_EDIT_DIFFUSE_B              1034
#define IDC_SPIN_POSITION_X             1034
#define IDC_EDIT_SHINE                  1035
#define IDC_EDIT_POSITION_Y             1035
#define IDC_SPIN_POSITION_Y             1036
#define IDC_EDIT_POSITION_Z             1037
#define IDC_SPIN3                       1038
#define IDC_SPIN_POSITION_Z             1038
#define ID_32771                        32771
#define ID_CAMERA_CONTROL               32772
#define ID_32774                        32774
#define ID_32775                        32775
#define ID_DISPLAY_CTRL                 32776
#define ID_LIGHT_MAT_CTLR               32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        328
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
