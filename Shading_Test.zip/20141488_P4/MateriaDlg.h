#pragma once
#include "afxcmn.h"
//#include "20141488_P4Doc.h"
//#include "20141488_P4View.h"
#include "MainFrm.h"

// CMateriaDlg ��ȭ �����Դϴ�.

class CMaterialDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CMaterialDlg)

public:
	CMaterialDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CMaterialDlg();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_MAT };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString m_strDiffuseR;
	CString m_strDiffuseG;
	CString m_strDiffuseB;
	CString m_strShine;
	CSliderCtrl m_sliderDiffuseR;
	CSliderCtrl m_sliderDiffuseG;
	CSliderCtrl m_sliderDiffuseB;
	CSliderCtrl m_sliderShine;
	virtual BOOL OnInitDialog();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
};
