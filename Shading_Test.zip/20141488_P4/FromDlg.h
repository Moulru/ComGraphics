#pragma once


// CFromDlg ��ȭ �����Դϴ�.

class CFromDlg : public CDialogEx
{
	DECLARE_DYNAMIC(CFromDlg)

public:
	CFromDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CFromDlg();

// ��ȭ ���� �������Դϴ�.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG_FROM };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	CString m_strFromX;
	CString m_strFromY;
	CString m_strFromZ;
	virtual BOOL OnInitDialog();
	afx_msg void OnDeltaposSpinFromX(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinFromY(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeltaposSpinFromZ(NMHDR *pNMHDR, LRESULT *pResult);
//	afx_msg void OnSpinAtX();
	afx_msg void OnClickedButtonResetFrom();
};
