// LightDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_P4.h"
#include "LightDlg.h"
#include "afxdialogex.h"
#include "20141488_P4Doc.h"
#include "20141488_P4View.h"
#include "MainFrm.h"

// CLightDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CLightDlg, CDialogEx)

CLightDlg::CLightDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_LIGHT, pParent)
	, m_strPositionX(_T(""))
	, m_strPositionY(_T(""))
	, m_strPositionZ(_T(""))
{

}

CLightDlg::~CLightDlg()
{
}

void CLightDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_POSITION_X, m_strPositionX);
	DDX_Text(pDX, IDC_EDIT_POSITION_Y, m_strPositionY);
	DDX_Text(pDX, IDC_EDIT_POSITION_Z, m_strPositionZ);
}


BEGIN_MESSAGE_MAP(CLightDlg, CDialogEx)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_POSITION_X, &CLightDlg::OnDeltaposSpinPositionX)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_POSITION_Y, &CLightDlg::OnDeltaposSpinPositionY)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_POSITION_Z, &CLightDlg::OnDeltaposSpinPositionZ)
END_MESSAGE_MAP()


// CLightDlg �޽��� ó�����Դϴ�.


void CLightDlg::OnDeltaposSpinPositionX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_fLightPos[0] += 5;
	}
	else {
		pView->m_fLightPos[0] -= 5;
	}
	m_strPositionX.Format(_T("%.1f"), pView->m_fLightPos[0]);
	UpdateData(FALSE);
	pView-> RedrawWindow();

	*pResult = 0;
}


void CLightDlg::OnDeltaposSpinPositionY(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_fLightPos[1] += 5;
	}
	else {
		pView->m_fLightPos[1] -= 5;
	}
	m_strPositionY.Format(_T("%.1f"), pView->m_fLightPos[1]);
	UpdateData(FALSE);
	pView->RedrawWindow();

	*pResult = 0;
}


void CLightDlg::OnDeltaposSpinPositionZ(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_fLightPos[2] += 5;
	}
	else {
		pView->m_fLightPos[2] -= 5;
	}
	m_strPositionZ.Format(_T("%.1f"), pView->m_fLightPos[2]);
	UpdateData(FALSE);
	pView->RedrawWindow();

	*pResult = 0;
}
