// UpDlg.cpp : ���� �����Դϴ�.
//

#include "stdafx.h"
#include "20141488_P4.h"
#include "UpDlg.h"
#include "afxdialogex.h"

#include "MainFrm.h"
#include "20141488_P4Doc.h"
#include "20141488_P4View.h"

// CUpDlg ��ȭ �����Դϴ�.

IMPLEMENT_DYNAMIC(CUpDlg, CDialogEx)

CUpDlg::CUpDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_DIALOG_UP, pParent)
	, m_strUpX(_T(""))
	, m_strUpY(_T(""))
	, m_strUpZ(_T(""))
{

}

CUpDlg::~CUpDlg()
{
}

void CUpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_UP_X, m_strUpX);
	DDX_Text(pDX, IDC_EDIT_UP_Y, m_strUpY);
	DDX_Text(pDX, IDC_EDIT_UP_Z, m_strUpZ);
}


BEGIN_MESSAGE_MAP(CUpDlg, CDialogEx)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_UP_X, &CUpDlg::OnDeltaposSpinUpX)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_UP_Y, &CUpDlg::OnDeltaposSpinUpY)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_UP_Z, &CUpDlg::OnDeltaposSpinUpZ)
	ON_BN_CLICKED(IDC_BUTTON_RESET_UP, &CUpDlg::OnClickedButtonResetUp)
END_MESSAGE_MAP()


// CUpDlg �޽��� ó�����Դϴ�.


BOOL CUpDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  ���⿡ �߰� �ʱ�ȭ �۾��� �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	m_strUpX.Format(_T("%.1f"), pView->m_Up[0]);
	m_strUpY.Format(_T("%.1f"), pView->m_Up[1]);
	m_strUpZ.Format(_T("%.1f"), pView->m_Up[2]);
	UpdateData(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
				  // ����: OCX �Ӽ� �������� FALSE�� ��ȯ�ؾ� �մϴ�.
}


void CUpDlg::OnDeltaposSpinUpX(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_Up[0]++;
	}
	else {
		pView->m_Up[0]--;
	}

	m_strUpX.Format(_T("%.1f"), pView->m_Up[0]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CUpDlg::OnDeltaposSpinUpY(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_Up[1]++;
	}
	else {
		pView->m_Up[1]--;
	}

	m_strUpY.Format(_T("%.1f"), pView->m_Up[1]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CUpDlg::OnDeltaposSpinUpZ(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMUPDOWN pNMUpDown = reinterpret_cast<LPNMUPDOWN>(pNMHDR);
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	if (pNMUpDown->iDelta < 0) {
		pView->m_Up[2]++;
	}
	else {
		pView->m_Up[2]--;
	}

	m_strUpZ.Format(_T("%.1f"), pView->m_Up[2]);
	UpdateData(FALSE);

	pView->RedrawWindow();

	*pResult = 0;
}


void CUpDlg::OnClickedButtonResetUp()
{
	// TODO: ���⿡ ��Ʈ�� �˸� ó���� �ڵ带 �߰��մϴ�.
	CMainFrame* pFrame = (CMainFrame*)AfxGetMainWnd();
	CMy20141488_P4View* pView = (CMy20141488_P4View*)(pFrame->GetActiveView());

	pView->m_Up[0] = 0;
	pView->m_Up[1] = 1;
	pView->m_Up[2] = 0;

	m_strUpX = "0.0";
	m_strUpY = "1.0";
	m_strUpZ = "0.0";

	UpdateData(FALSE);
	pView->RedrawWindow();

}
