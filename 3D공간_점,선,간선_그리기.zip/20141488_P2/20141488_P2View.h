
// 20141488_P2View.h : CMy20141488_P2View Ŭ������ �������̽�
//

#pragma once
#include "atltypes.h"

#define GL_PI			3.141519f
#define GL_POINTS_MODE	1
#define GL_LINES_MODE	2
#define GL_EDGE_MODE	3

class CMy20141488_P2View : public CView
{
protected: // serialization������ ��������ϴ�.
	CMy20141488_P2View();
	DECLARE_DYNCREATE(CMy20141488_P2View)

// Ư���Դϴ�.
public:
	CMy20141488_P2Doc* GetDocument() const;

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual void OnDraw(CDC* pDC);  // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// �����Դϴ�.
public:
	virtual ~CMy20141488_P2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	DECLARE_MESSAGE_MAP()
public:
	HGLRC m_hRC;
	CDC* m_pDC;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	bool InitializeOpenGL();
	bool SetupPixelFormat();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	void RenderScene();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	GLfloat m_fRotX;
	GLfloat m_fRotY;
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	CPoint m_ptMouseDown;
	bool m_bRotate;
	bool m_bZoom;
	GLfloat m_fTransZ;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	GLint m_nDrawMode;
	bool m_bEdgeFlag;
	afx_msg void OnGlPoints();
	afx_msg void OnGlLines();
	afx_msg void OnEdgeFlagEnable();
	afx_msg void OnEdgeFlagDisable();
};

#ifndef _DEBUG  // 20141488_P2View.cpp�� ����� ����
inline CMy20141488_P2Doc* CMy20141488_P2View::GetDocument() const
   { return reinterpret_cast<CMy20141488_P2Doc*>(m_pDocument); }
#endif

