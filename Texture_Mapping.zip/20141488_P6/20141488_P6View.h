
// 20141488_P6View.h : CMy20141488_P6View Ŭ������ �������̽�
//

#pragma once
#include "atltypes.h"


class CMy20141488_P6View : public CView
{
protected: // serialization������ ��������ϴ�.
	CMy20141488_P6View();
	DECLARE_DYNCREATE(CMy20141488_P6View)

// Ư���Դϴ�.
public:
	CMy20141488_P6Doc* GetDocument() const;

// �۾��Դϴ�.
public:

// �������Դϴ�.
public:
	virtual void OnDraw(CDC* pDC);  // �� �並 �׸��� ���� �����ǵǾ����ϴ�.
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// �����Դϴ�.
public:
	virtual ~CMy20141488_P6View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// ������ �޽��� �� �Լ�
protected:
	DECLARE_MESSAGE_MAP()
public:
	HGLRC m_hRC;
	CDC* m_pDC;
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	bool InitializeOpenGL();
	bool SetupPixelFormat();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	void RenderScene();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnDestroy();
	GLfloat m_fRotX;
	GLfloat m_fRotY;
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	CPoint m_ptMouseDown;
	bool m_bRotate;
	bool m_bZoom;
	GLfloat m_fTransZ;
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	bool m_bTexture1D;
	bool m_bTexture2D;
	GLuint m_nTexture[7];
	bool m_bBillBoardOff;
	bool m_bBillBoardOn;
	afx_msg void OnTexture1d();
	GLuint TextureLoad(LPCWSTR filename);
	afx_msg void OnTexture2d();
	afx_msg void OnBillboardOff();
	afx_msg void OnBillboardOn();
};

#ifndef _DEBUG  // 20141488_P6View.cpp�� ����� ����
inline CMy20141488_P6Doc* CMy20141488_P6View::GetDocument() const
   { return reinterpret_cast<CMy20141488_P6Doc*>(m_pDocument); }
#endif

