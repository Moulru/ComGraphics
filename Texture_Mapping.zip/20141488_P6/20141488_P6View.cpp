
// 20141488_P6View.cpp : CMy20141488_P6View Ŭ������ ����
//

#include "stdafx.h"
// SHARED_HANDLERS�� �̸� ����, ����� �׸� �� �˻� ���� ó���⸦ �����ϴ� ATL ������Ʈ���� ������ �� ������
// �ش� ������Ʈ�� ���� �ڵ带 �����ϵ��� �� �ݴϴ�.
#ifndef SHARED_HANDLERS
#include "20141488_P6.h"
#endif

#include "20141488_P6Doc.h"
#include "20141488_P6View.h"
#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define M_PI	3.14159

// CMy20141488_P6View

IMPLEMENT_DYNCREATE(CMy20141488_P6View, CView)

BEGIN_MESSAGE_MAP(CMy20141488_P6View, CView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_TEXTURE_1D, &CMy20141488_P6View::OnTexture1d)
	ON_COMMAND(ID_TEXTURE_2D, &CMy20141488_P6View::OnTexture2d)
	ON_COMMAND(ID_BILLBOARD_OFF, &CMy20141488_P6View::OnBillboardOff)
	ON_COMMAND(ID_BILLBOARD_ON, &CMy20141488_P6View::OnBillboardOn)
END_MESSAGE_MAP()

// CMy20141488_P6View ����/�Ҹ�

CMy20141488_P6View::CMy20141488_P6View()
	: m_pDC(NULL)
	, m_fRotX(0)
	, m_fRotY(0)
	, m_ptMouseDown(0)
	, m_bRotate(false)
	, m_bZoom(false)
	, m_fTransZ(0)
	, m_bTexture1D(false)
	, m_bTexture2D(false)
	, m_bBillBoardOff(false)
	, m_bBillBoardOn(false)
{
	// TODO: ���⿡ ���� �ڵ带 �߰��մϴ�.
	m_fRotX = 0.0f;
	m_fRotX = 0.0f;

	m_ptMouseDown = 0.0f;

	m_bRotate = FALSE;
	m_bZoom = FALSE;

	m_fTransZ = -250;

	m_bTexture1D = FALSE;
	m_bTexture2D = FALSE;
	m_bBillBoardOff = FALSE;
	m_bBillBoardOn = FALSE;

}

CMy20141488_P6View::~CMy20141488_P6View()
{
}

BOOL CMy20141488_P6View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs�� �����Ͽ� ���⿡��
	//  Window Ŭ���� �Ǵ� ��Ÿ���� �����մϴ�.
	cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

	return CView::PreCreateWindow(cs);
}

// CMy20141488_P6View �׸���

void CMy20141488_P6View::OnDraw(CDC* pDC)
{
	CMy20141488_P6Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: ���⿡ ���� �����Ϳ� ���� �׸��� �ڵ带 �߰��մϴ�.
	::glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	RenderScene();
	::glFinish();

	::SwapBuffers(m_pDC->GetSafeHdc());

}


// CMy20141488_P6View ����

#ifdef _DEBUG
void CMy20141488_P6View::AssertValid() const
{
	CView::AssertValid();
}

void CMy20141488_P6View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy20141488_P6Doc* CMy20141488_P6View::GetDocument() const // ����׵��� ���� ������ �ζ������� �����˴ϴ�.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy20141488_P6Doc)));
	return (CMy20141488_P6Doc*)m_pDocument;
}
#endif //_DEBUG


// CMy20141488_P6View �޽��� ó����


int CMy20141488_P6View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  ���⿡ Ư��ȭ�� �ۼ� �ڵ带 �߰��մϴ�.
	InitializeOpenGL();

	return 0;
}


bool CMy20141488_P6View::InitializeOpenGL()
{
	m_pDC = new CClientDC(this);
	// �Լ��� ù��°�� Ŭ���̾�Ʈ ������ ���� DC�� ��� NULL�� �ƴ��� Ȯ��
	if (m_pDC == NULL) {
		MessageBox(_T("Error Obtaining DC"));
		return false;
	}

	// �ȼ� ������ �����ϱ����� �Լ�ȣ�� �� ����Ȯ��
	if (!SetupPixelFormat()) {
		return FALSE;
	}

	m_hRC = ::wglCreateContext(m_pDC->GetSafeHdc());
	if (m_hRC == 0) {
		MessageBox(_T("Error Creating RC"));
		return false;
	}

	if (::wglMakeCurrent(m_pDC->GetSafeHdc(), m_hRC) == FALSE) {
		MessageBox(_T("Error making RC Current"));
		return false;
	}

	::glClearColor(0.0f, 0.0f, 0.0f, 0.0f);

	::glClearDepth(1.0f);

	::glEnable(GL_DEPTH_TEST);

	glGenTextures(6, m_nTexture);

	m_nTexture[0] = TextureLoad(_T("texture1.bmp"));
	m_nTexture[1] = TextureLoad(_T("texture2.bmp"));
	m_nTexture[2] = TextureLoad(_T("texture3.bmp"));
	m_nTexture[3] = TextureLoad(_T("texture4.bmp"));
	m_nTexture[4] = TextureLoad(_T("texture5.bmp"));
	m_nTexture[5] = TextureLoad(_T("texture6.bmp"));
	m_nTexture[6] = TextureLoad(_T("cactus.bmp"));

	return TRUE;
}


bool CMy20141488_P6View::SetupPixelFormat()
{
	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),
		1,
		PFD_DRAW_TO_WINDOW |
		PFD_SUPPORT_OPENGL |
		PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA,
		24,
		0,0,0,0,0,0,
		0,
		0,
		0,
		0,0,0,0,
		16,
		0,
		0,
		PFD_MAIN_PLANE,
		0,
		0,0,0
	};

	int m_nPixelFormat = ::ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd);
	if (m_nPixelFormat == 0) {
		return FALSE;
	}

	if (::SetPixelFormat(m_pDC->GetSafeHdc(), m_nPixelFormat, &pfd) == FALSE) {
		return FALSE;
	}

	return TRUE;

}


void CMy20141488_P6View::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	GLdouble aspect_ratio;

	if (0 >= cx || 0 >= cy) {
		return;
	}

	::glViewport(0, 0, cx, cy);
	aspect_ratio = (GLdouble)cx / (GLdouble)cy;

	::glMatrixMode(GL_PROJECTION);
	::glLoadIdentity();

	::gluPerspective(45.0f, aspect_ratio, 0.01f, 200.0f);

	::glMatrixMode(GL_MODELVIEW);
	::glLoadIdentity();

}


void CMy20141488_P6View::RenderScene()
{
	if (m_bTexture1D) {
		GLfloat x, y, z, th;
		static GLubyte roygbiv_image[8][3] = {
			{0x00, 0x00, 0xff},
			{0x00, 0xff, 0x00},
			{0xff, 0xff, 0x00},
			{0xff, 0x7f, 0x00},
			{0xff, 0x00, 0x00}
		};

		glClearColor(0.5, 0.5, 1.0, 1.0);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexImage1D(GL_TEXTURE_1D, 0, 3, 8, 0, GL_RGB, GL_UNSIGNED_BYTE, roygbiv_image);

		glDisable(GL_TEXTURE_1D);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glPushMatrix();
		glRotatef(10.0, 0.0, 1.0, 0.0);
		glTranslatef(0.0, -40.0, -100.0);
		glColor3f(0.0, 0.8, 0.0);
		glBegin(GL_POLYGON);
		for (th = 0.0; th < (2.0*M_PI); th += (0.03125*M_PI)) {
			x = cos(th) *200.0;
			z = sin(th) *200.0;
			glVertex3f(x, 0.0, z);
		}
		glEnd();

		glEnable(GL_TEXTURE_1D);
		glBegin(GL_QUAD_STRIP);
		for (th = 0.0; th <= M_PI; th += (0.03125 * M_PI)) {
			x = cos(th) * 50.0;
			y = sin(th) * 50.0;
			z = -50.0;
			glTexCoord1f(0.0);
			glVertex3f(x, y, z);
			x = cos(th) *55.0;
			y = sin(th) *55.0;
			z = -50.0;
			glTexCoord1f(1.0);
			glVertex3f(x, y, z);
		}
		glEnd();
		glPopMatrix();
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_1D);
	}

	if (m_bTexture2D) {
		GLfloat ambientLight[] = { 0.25f, 0.25f, 0.25f, 1.0f };
		GLfloat diffuseLight[] = { 0.9f, 0.9f, 0.9f, 1.0f };
		GLfloat lightPos[] = { -100.0f, 130.0f, 150.0f, 1.0f };
		GLfloat specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		GLfloat specref[] = { 1.0f, 1.0f, 1.0f, 1.0f };
		glEnable(GL_TEXTURE_2D);
		glShadeModel(GL_SMOOTH);

		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glEnable(GL_CULL_FACE);
		glEnable(GL_LIGHTING);

		glLightfv(GL_LIGHT0, GL_AMBIENT, ambientLight);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseLight);
		glLightfv(GL_LIGHT0, GL_POSITION, lightPos);
		glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
		glEnable(GL_LIGHT0);

		glEnable(GL_COLOR_MATERIAL);
		glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
		glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
		glMateriali(GL_FRONT, GL_SHININESS, 10);
		glDepthFunc(GL_LEQUAL);

		glPushMatrix();
		glTranslatef(0.0f, 0.0f, -7.0f);
		glRotatef(m_fRotX, 1.0f, 0.0f, 0.0f);
		glRotatef(m_fRotY, 0.0f, 1.0f, 0.0f);

		glPushMatrix();
		glColor3f(0.8f, 0.8f, 0.8f);

		// �ո�
		glBindTexture(GL_TEXTURE_2D, m_nTexture[0]);
		glBegin(GL_QUADS);
			glNormal3f(0.0f, 0.0f, 1.0f);
			glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
			glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
			glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);
			glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glEnd();

		// ������
		glBindTexture(GL_TEXTURE_2D, m_nTexture[1]);
		glBegin(GL_QUADS);
		glNormal3f(1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
		glEnd();

		// �޸�
		glBindTexture(GL_TEXTURE_2D, m_nTexture[2]);
		glBegin(GL_QUADS);
		glNormal3f(0.0f, 0.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glEnd();

		// ������
		glBindTexture(GL_TEXTURE_2D, m_nTexture[3]);
		glBegin(GL_QUADS);
		glNormal3f(-1.0f, 0.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glEnd();

		// �ظ�
		glBindTexture(GL_TEXTURE_2D, m_nTexture[4]);
		glBegin(GL_QUADS);
		glNormal3f(0.0f, -1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, -1.0f);
		glEnd();

		// ����
		glBindTexture(GL_TEXTURE_2D, m_nTexture[5]);
		glBegin(GL_QUADS);
		glNormal3f(0.0f, 1.0f, 0.0f);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, 1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.0f, 1.0f, -1.0f);
		glEnd();

		glPopMatrix();
		glPopMatrix();
		glDisable(GL_CULL_FACE);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_LIGHT0);
		glDisable(GL_LIGHTING);
		glDisable(GL_TEXTURE_2D);

	}

	if (m_bBillBoardOff) {
		glEnable(GL_TEXTURE_2D);
		glShadeModel(GL_SMOOTH);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glPushMatrix();
		glTranslatef(0.0f, 0.0f, -7.0f);
		glRotatef(m_fRotY, 0.0f, 1.0f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, m_nTexture[6]);

		glPushMatrix();
		glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);	glVertex3f(-1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 0.0f);	glVertex3f(1.0f, -1.0f, 1.0f);
		glTexCoord2f(1.0f, 1.0f);	glVertex3f(1.0f, 1.0f, 1.0f);
		glTexCoord2f(0.0f, 1.0f);	glVertex3f(-1.0f, 1.0f, 1.0f);
		glEnd();
		glPopMatrix();
		glPopMatrix();
	}

	if (m_bBillBoardOn) {
		glEnable(GL_TEXTURE_2D);
		glShadeModel(GL_SMOOTH);
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);

		glPushMatrix();
		glTranslatef(0.0f, 0.0f, -7.0f);
		glRotatef(m_fRotY, 0.0f, 1.0f, 0.0f);

		glBindTexture(GL_TEXTURE_2D, m_nTexture[6]);

		// �� �� ����� ��´�.
		float mat[16], right[3], up[3], center_pos[3], bill_polygon[4][3];
		glGetFloatv(GL_MODELVIEW_MATRIX, mat);

		// �� �� ��ķκ��� �ü����⿡ ���� �������� ������ ���Ϳ� ��������
		// ���� ���͸� �����Ѵ�.
		right[0] = mat[0];		right[1] = mat[4];		right[2] = mat[8];
		up[0] = mat[1];			up[1] = mat[5];			up[2] = mat[9];
		center_pos[0] = 0.0f;	center_pos[1] = 0.0f;	center_pos[2] = 1.0f;

		for (int i = 0; i < 3; i++) {
			bill_polygon[0][i] = center_pos[i] + (right[i] + up[i]) * (-1);
			bill_polygon[1][i] = center_pos[i] + (right[i] - up[i]) * (+1);
			bill_polygon[2][i] = center_pos[i] + (right[i] + up[i]) * (+1);
			bill_polygon[3][i] = center_pos[i] + (up[i] - right[i]) * (+1);
		}
		glPushMatrix();

		glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);	glVertex3fv(bill_polygon[0]);
		glTexCoord2f(1.0f, 0.0f);	glVertex3fv(bill_polygon[1]);
		glTexCoord2f(1.0f, 1.0f);	glVertex3fv(bill_polygon[2]);
		glTexCoord2f(0.0f, 1.0f);	glVertex3fv(bill_polygon[3]);
		glEnd();

		glPopMatrix();
		glPopMatrix();

		// �� �� ��ķκ��� �ü����⿡ ���� �������� ������ ���Ϳ� ���� ���͸� �����Ѵ�.
		right[0] = mat[0];		right[1] = mat[4];		right[2] = mat[8];
		up[0] = mat[1];			up[1] = mat[5];			up[2] = mat[9];
		center_pos[0] = 0.0f;	center_pos[1] = 0.0f;	center_pos[2] = 1.0f;

		for (int i = 0; i < 3; i++) {
			bill_polygon[0][i] = center_pos[i] + (right[i] + up[i]) * (-1);
			bill_polygon[1][i] = center_pos[i] + (right[i] - up[i]) * (+1);
			bill_polygon[2][i] = center_pos[i] + (right[i] + up[i]) * (+1);
			bill_polygon[3][i] = center_pos[i] + (up[i] - right[i]) * (+1);
		}
		glPushMatrix();

		glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);	glVertex3fv(bill_polygon[0]);
		glTexCoord2f(1.0f, 0.0f);	glVertex3fv(bill_polygon[1]);
		glTexCoord2f(1.0f, 1.0f);	glVertex3fv(bill_polygon[2]);
		glTexCoord2f(0.0f, 1.0f);	glVertex3fv(bill_polygon[3]);
		glEnd();

		glPopMatrix();
		glPopMatrix();
	}
}


BOOL CMy20141488_P6View::OnEraseBkgnd(CDC* pDC)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.

	return TRUE;
}


void CMy20141488_P6View::OnDestroy()
{
	CView::OnDestroy();

	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰��մϴ�.
	if (::wglMakeCurrent(0, 0) == FALSE) {
		MessageBox(_T("Could not make RC non-current"));
	}

	if (::wglDeleteContext(m_hRC) == FALSE) {
		MessageBox(_T("Could not delete RC"));
	}

	if (m_pDC) {
		delete m_pDC;
	}
	m_pDC = NULL;


}


void CMy20141488_P6View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	switch (nChar)
	{
	case VK_UP:
		m_fRotX -= 5.0f;
		break;

	case VK_DOWN:
		m_fRotX += 5.0f;
		break;

	case VK_LEFT:
		m_fRotY -= 5.0f;
		break;

	case VK_RIGHT:
		m_fRotY += 5.0f;
		break;
	}
	RedrawWindow();

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}


void CMy20141488_P6View::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_bRotate = TRUE;
	m_bZoom = FALSE;
	m_ptMouseDown = point;
	SetCapture();

	HCURSOR hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_ROTATE);
	SetCursor(hCursor);

	CRect rectClient;
	GetClientRect(&rectClient);
	ClientToScreen(&rectClient);
	::ClipCursor(&rectClient);


	CView::OnLButtonDown(nFlags, point);
}


void CMy20141488_P6View::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_ptMouseDown = CPoint(0, 0);
	ReleaseCapture();
	::ClipCursor(NULL);

	CView::OnLButtonUp(nFlags, point);
}


void CMy20141488_P6View::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_bRotate = FALSE;
	m_bZoom = TRUE;
	m_ptMouseDown = point;
	SetCapture();

	HCURSOR hCursor = AfxGetApp()->LoadCursor(IDC_CURSOR_ZOOM);
	SetCursor(hCursor);

	CRect rectClient;
	GetClientRect(&rectClient);
	ClientToScreen(&rectClient);
	::ClipCursor(&rectClient);

	CView::OnRButtonDown(nFlags, point);
}


void CMy20141488_P6View::OnRButtonUp(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	m_ptMouseDown = CPoint(0, 0);
	ReleaseCapture();
	::ClipCursor(NULL);

	CView::OnRButtonUp(nFlags, point);
}


void CMy20141488_P6View::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: ���⿡ �޽��� ó���� �ڵ带 �߰� ��/�Ǵ� �⺻���� ȣ���մϴ�.
	if (m_bRotate) {
		if (GetCapture() == this) {
			m_fRotX += (point.y - m_ptMouseDown.y) / 3.6;
			m_fRotY += (point.x - m_ptMouseDown.x) / 3.6;
		}
	}
	if (m_bZoom) {
		if (GetCapture() == this) {
			m_fTransZ += (point.y - m_ptMouseDown.y);
		}
	}

	m_ptMouseDown = point;
	InvalidateRect(NULL, FALSE);


	CView::OnMouseMove(nFlags, point);
}


void CMy20141488_P6View::OnTexture1d()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_bTexture1D = TRUE;
	m_bTexture2D = FALSE;
	m_bBillBoardOff = FALSE;
	m_bBillBoardOn = FALSE;

	InvalidateRect(NULL, FALSE);
}


GLuint CMy20141488_P6View::TextureLoad(LPCWSTR filename)
{
	AUX_RGBImageRec*	texture;
	GLuint				texObject;

	texture = auxDIBImageLoad(filename);
	if (!texture) {
		MessageBox(_T("Picture could not be loaded"));
		exit(1);
	}

	glGenTextures(1, &texObject);
	glBindTexture(GL_TEXTURE_2D, texObject);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexEnvi(GL_TEXTURE_2D, GL_TEXTURE_ENV_MODE, GL_MODULATE);

	glTexImage2D(GL_TEXTURE_2D, 0, 3, texture->sizeX, texture->sizeY,
		0, GL_RGB, GL_UNSIGNED_BYTE, texture->data);

	return (texObject);
}


void CMy20141488_P6View::OnTexture2d()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_bTexture1D = FALSE;
	m_bTexture2D = TRUE;
	m_bBillBoardOff = FALSE;
	m_bBillBoardOn = FALSE;

	InvalidateRect(NULL, FALSE);
}


void CMy20141488_P6View::OnBillboardOff()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_bTexture1D = FALSE;
	m_bTexture2D = FALSE;
	m_bBillBoardOff = TRUE;
	m_bBillBoardOn = FALSE;

	InvalidateRect(NULL, FALSE);
}


void CMy20141488_P6View::OnBillboardOn()
{
	// TODO: ���⿡ ���� ó���� �ڵ带 �߰��մϴ�.
	m_bTexture1D = FALSE;
	m_bTexture2D = FALSE;
	m_bBillBoardOff = FALSE;
	m_bBillBoardOn = TRUE;

	InvalidateRect(NULL, FALSE);
}
